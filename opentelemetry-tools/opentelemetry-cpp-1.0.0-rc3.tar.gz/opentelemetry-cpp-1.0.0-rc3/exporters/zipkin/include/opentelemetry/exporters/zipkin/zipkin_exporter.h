// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "opentelemetry/exporters/zipkin/recordable.h"
#include "opentelemetry/ext/http/client/http_client_factory.h"
#include "opentelemetry/ext/http/common/url_parser.h"
#include "opentelemetry/sdk/trace/exporter.h"
#include "opentelemetry/sdk/trace/span_data.h"

#include "nlohmann/json.hpp"

OPENTELEMETRY_BEGIN_NAMESPACE
namespace exporter
{
namespace zipkin
{

inline const std::string GetDefaultZipkinEndpoint()
{
  const char *otel_exporter_zipkin_endpoint_env = "OTEL_EXPORTER_ZIPKIN_ENDPOINT";
  const char *kZipkinEndpointDefault            = "http://localhost:9411/api/v2/spans";

#if defined(_MSC_VER)
  // avoid calling std::getenv which is deprecated in MSVC.
  size_t required_size = 0;
  getenv_s(&required_size, nullptr, 0, otel_exporter_zipkin_endpoint_env);
  const char *endpoint_from_env = nullptr;
  std::unique_ptr<char> endpoint_buffer;
  if (required_size > 0)
  {
    endpoint_buffer = std::unique_ptr<char>{new char[required_size]};
    getenv_s(&required_size, endpoint_buffer.get(), required_size,
             otel_exporter_zipkin_endpoint_env);
    endpoint_from_env = endpoint_buffer.get();
  }
#else
  auto endpoint_from_env = std::getenv(otel_exporter_zipkin_endpoint_env);
#endif
  return std::string{endpoint_from_env ? endpoint_from_env : kZipkinEndpointDefault};
}

/**
 * Struct to hold Zipkin  exporter options.
 */
struct ZipkinExporterOptions
{
  // The endpoint to export to. By default the OpenTelemetry Collector's default endpoint.
  std::string endpoint     = GetDefaultZipkinEndpoint();
  TransportFormat format   = TransportFormat::kJson;
  std::string service_name = "default-service";
  std::string ipv4;
  std::string ipv6;
};

namespace trace_sdk   = opentelemetry::sdk::trace;
namespace http_client = opentelemetry::ext::http::client;

/**
 * The Zipkin exporter exports span data in JSON format as expected by Zipkin
 */
class ZipkinExporter final : public trace_sdk::SpanExporter
{
public:
  /**
   * Create a ZipkinExporter using all default options.
   */
  ZipkinExporter();

  /**
   * Create a ZipkinExporter using the given options.
   */
  explicit ZipkinExporter(const ZipkinExporterOptions &options);

  /**
   * Create a span recordable.
   * @return a newly initialized Recordable object
   */
  std::unique_ptr<trace_sdk::Recordable> MakeRecordable() noexcept override;

  /**
   * Export a batch of span recordables in JSON format.
   * @param spans a span of unique pointers to span recordables
   */
  sdk::common::ExportResult Export(
      const nostd::span<std::unique_ptr<trace_sdk::Recordable>> &spans) noexcept override;

  /**
   * Shut down the exporter.
   * @param timeout an optional timeout, default to max.
   */
  bool Shutdown(
      std::chrono::microseconds timeout = std::chrono::microseconds::max()) noexcept override
  {
    return true;
  }

private:
  void InitializeLocalEndpoint();

private:
  // The configuration options associated with this exporter.
  bool isShutdown_ = false;
  ZipkinExporterOptions options_;
  std::shared_ptr<http_client::HttpClientSync> http_client_;
  opentelemetry::ext::http::common::UrlParser url_parser_;
  nlohmann::json local_end_point_;
};
}  // namespace zipkin
}  // namespace exporter
OPENTELEMETRY_END_NAMESPACE
